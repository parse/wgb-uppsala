Starta med wgb.py

Spelet g�r ut p� att h�lla bollarna i luften s� l�nge som m�jligt.
Styr plattan h�ger/v�nster med musen
N�r den gr�na m�taren (h�gst upp p� sk�rmen) fyllts s� tillkommer en till boll och eventuellt en till v�gg.

Instruktioner finns p� knappen "i"

Lycka till!

Projektets hemsida
https://code.google.com/p/wgb-uppsala/